"use strict";

function pieChart() {
	
	//circle progress bar
	if (jQuery().easyPieChart) {
		var count = 0 ;
		// var colors = ['#55bce9', '#7370b5', '#6496cf'];
		var colors = ['#55bce9'];

		jQuery('.chart').each(function(){
			
			var imagePos = jQuery(this).offset().top;
			var topOfWindow = jQuery(window).scrollTop();
			if (imagePos < topOfWindow+900) {

				jQuery(this).easyPieChart({
			        barColor: colors[count],
					trackColor: '#ffffff',
					scaleColor: false,
					scaleLength: false,
					lineCap: 'butt',
					lineWidth: 20,
					size: 270,
					rotate: 0,
					animate: 3000,
					onStep: function(from, to, percent) {
							jQuery(this.el).find('.percent').text(Math.round(percent));
						}
			    });
			}
			count++;
			if (count >= colors.length) { count = 0};
		});
	}
}


jQuery(document).ready(function() {
	//background image teaser
	jQuery(".bg_teaser").each(function(){
		var imagePath = jQuery(this).find("img").first().attr("src");
		jQuery(this).css("background-image", "url(" + imagePath + ")").prepend('<div class="bg_overlay"/>');
	});

	
	///////////
	//Plugins//
	///////////
    //contact form processing
    jQuery('form.contact-form').on('submit', function( e ){
        e.preventDefault();
        var $form = jQuery(this);
        jQuery($form).find('span.contact-form-respond').remove();
        //checking on empty values
        var formFields = $form.serializeArray();
        for (var i = formFields.length - 1; i >= 0; i--) {
        	if (!formFields[i].value.length) {
        		$form.find('[name="' + formFields[i].name + '"]').addClass('invalid').on('focus', function(){jQuery(this).removeClass('invalid')});
        	};
        };
        //if one of form fields is empty - exit
        if ($form.find('[name]').hasClass('invalid')) {
        	return;
        };
        //sending form data to PHP server if fields are not empty
        var request = $form.serialize();
        var ajax = jQuery.post( "contact-form.php", request )
            .done(function( data ) {
                jQuery($form).find('[type="submit"]').attr('disabled', false).parent().append('<span class="contact-form-respond highlight">'+data+'</span>');
        })
            .fail(function( data ) {
                jQuery($form).find('[type="submit"]').attr('disabled', false).parent().append('<span class="contact-form-respond highlight">Mail cannot be sent. You need PHP server to send mail.</span>');
        })
    });
    
    //mailchimp subscribe form processing
    jQuery('#signup').on('submit', function( e ) {
        e.preventDefault();
        // update user interface
        jQuery('#response').html('Adding email address...');
        // Prepare query string and send AJAX request
        jQuery.ajax({
            url: 'mailchimp/store-address.php',
            data: 'ajax=true&email=' + escape(jQuery('#mailchimp_email').val()),
            success: function(msg) {
                jQuery('#response').html(msg);
            }
        });
    });
	
	//twitter
	//slide tweets
	jQuery('#tweets .twitter').bind('loaded', function(){
		jQuery(this).addClass('flexslider').find('ul').addClass('slides');
	});
	if (jQuery().tweet) {
		jQuery('.twitter').tweet({
			modpath: "./twitter/",
		    count: 2,
		    avatar_size: 48,
		    loading_text: 'loading twitter feed...',
		    join_text: 'auto',
		    username: 'ThemeForest', 
		    template: "{avatar}<div class=\"tweet_right\">{time}{join}<span class=\"tweet_text\">{tweet_text}</span></div>"
		});
	}


	//mainmenu
	if (jQuery().superfish) {
		jQuery('ul.sf-menu').superfish({
			delay:       300,
			animation:   {opacity:'show'},
			animationOut: {opacity: 'hide'},
			speed:       'fast',
			disableHI:   false,
			cssArrows:   true,
			autoArrows:  true
		});
	}

		//toggle mobile menu
	jQuery('#toggle_menu').on('click', function(){
		jQuery('#toggle_menu').toggleClass('mobile-active');
		jQuery('#header').toggleClass('mobile-active');
	});

	jQuery('#mainmenu a').on('click', function(){
		if (!jQuery(this).hasClass('sf-with-ul')) {
			jQuery('#toggle_menu').toggleClass('mobile-active');
			jQuery('#header').toggleClass('mobile-active');
		}
	});
		
    
	//single page localscroll and scrollspy
	var navHeight = jQuery('#header').outerHeight(true);
	jQuery('body').scrollspy({
		target: '#mainmenu_wrapper',
		offset: navHeight
	});
	if (jQuery().localScroll) {
		jQuery('#mainmenu, #land').localScroll({
			duration:900,
			easing:'easeInOutQuart',
			offset: -navHeight+10
		});
	}

	//stick header to top
	var $affixHeader = jQuery('#header');
	var headerOffset = jQuery('#topline').outerHeight(true) + jQuery('#toplogo').outerHeight(true);
	jQuery($affixHeader).affix({
		offset: {
			top: headerOffset,
			bottom: 0
		}
	});
	

	//if header has different height on afixed and affixed-top positions - correcting wrapper height
	jQuery($affixHeader).on('affixed-top.bs.affix', function () {
		$affixHeader.parent().css({height: $affixHeader.outerHeight()});
	});


	//toTop
	if (jQuery().UItoTop) {
        jQuery().UItoTop({ easingType: 'easeOutQuart' });
    }

	//parallax
	if (jQuery().parallax) {
		jQuery('#contact').parallax("50%", -0.01);
		jQuery('#featured').parallax("50%", -0.01);
	}
	


    //prettyPhoto
    if (jQuery().prettyPhoto) {
	   	jQuery("a[data-gal^='prettyPhoto']").prettyPhoto({
	   		hook: 'data-gal',
			theme: 'facebook' /* light_rounded / dark_rounded / light_square / dark_square / facebook / pp_default*/
	  	});
	}

   	//tooltip
   	if (jQuery().tooltip) {
		jQuery('[data-toggle="tooltip"]').tooltip();
	}

   	//carousel
   	if (jQuery().carousel) {
		jQuery('.carousel').carousel();
	}

	//owl carousel
	if (jQuery().owlCarousel) {

		//partners carousel
		jQuery('#partners-carousel').owlCarousel({
		    loop:false,
		    margin:30,
		    nav:true,
		    dots:false,
		    items: 4,
		    responsive:{
		        0:{
		            items:1
		        },
		        767:{
		            items:3
		        },
		        1200:{
		            items: 4
		        }
		    }
		});

		jQuery('#small-carousel').owlCarousel({
		    loop:false,
		    margin:30,
		    nav:true,
		    dots:false,
		    items: 3,
		    responsive:{
		        0:{
		            items:1
		        },
		        767:{
		            items: 2
		        },
		        1200:{
		            items:3
		        }
		    }
		});

		jQuery('#photo-carousel').owlCarousel({
		    loop:true,
		    margin:0,
		    center: true,
		    nav:true,
		    dots:false,
		    items: 3,
		    responsive:{
		        0:{
		            items:1
		        },
		        400:{
		            items:1
		        },
		        767:{
		            items: 2
		        },
		        992:{
		            items: 2
		        },
		        1200:{
		            items:3
		        },
		        1600:{
		            items:4
		        }
		    }
		});

		//related items carousel
		jQuery('#related-carousel').owlCarousel({
		    loop:false,
		    margin:0,
		    nav:false,
		    dots:false,
		    items: 4,
		    responsive:{
		        0:{
		            items:1
		        },
		        767:{
		            items:3
		        },
		        1200:{
		            items: 4
		        }
		    }
		});

		//single product carousel
		jQuery('#product-thumbnails').owlCarousel({
		    loop:false,
		    margin:10,
		    nav:true,
		    dots:false,
		    items: 3,
		    themeClass: 'product-gallery-thumbnails'
		});

		//slogans carousel
		jQuery('.owl-carousel.single-slide').owlCarousel({
		    loop:false,
		    autoplay:true,
			autoplayTimeout:5000,
			animateIn: 'fadeInLeft',
		    animateOut: 'fadeOut',
		    margin:0,
		    nav:false,
		    dots:true,
		    items: 1,
		    
		});

		//common carousel
		jQuery('.owl-carousel').owlCarousel({
		    loop:false,
		    margin:30,
		    nav:false,
		    dots:true,
		    items: 4,
		    responsive:{
		        0:{
		            items:1
		        },
		        767:{
		            items:3
		        },
		        1200:{
		            items: 4
		        }
		    }
		});

		//gallery carousel layout
		var $owlGallery = jQuery('#gallery-owl-carousel')
		if ($owlGallery.length) {
			var itemsNumber = jQuery($owlGallery).data('items');
			jQuery($owlGallery).owlCarousel({
			    loop:true,
			    margin:30,
			    nav:true,
			    dots:false,
			    items: itemsNumber,
			    responsive:{
			        0:{
			            items:1
			        },
			        767:{
			            items:2
			        },
			        992:{
			            items:2
			        },
			        1200:{
			            items: itemsNumber
			        }
			    }
			});
		}

	}
	
	//comingsoon counter
	if (jQuery().countdown) {
		//today date plus month for demo purpose
		var demoDate = new Date();
		demoDate.setMonth(demoDate.getMonth()+1);
		jQuery('#comingsoon-countdown').countdown({until: demoDate});
	}


	/////////
	//shop///
	/////////
	jQuery('#toggle_shop_view').on('click', function( e ) {
		e.preventDefault();
		jQuery(this).toggleClass('grid-view');
		jQuery('#products').toggleClass('grid-view list-view');
	});
	
	//zoom image
	if (jQuery().elevateZoom) {
		jQuery('#product-image').elevateZoom({
			gallery: 'product-image-gallery',
			cursor: 'pointer', 
			galleryActiveClass: 'active', 
			responsive:true, 
			loadingIcon: 'img/AjaxLoader.gif'
		});
	}
	
	//add review button
	jQuery('.review-link').on('click', function( e ) {
		var thisLink = jQuery(this);
		var reviewTabLink = jQuery('a[href="#reviews_tab"]');
		//show tab only if it's hidden
		if (!reviewTabLink.parent().hasClass('active')) {
			reviewTabLink
				.tab('show')
				.on('shown.bs.tab', function (e) {
					jQuery(window).scrollTo(jQuery(thisLink).attr('href'), 400);
				})
		}
		jQuery(window).scrollTo(jQuery(thisLink).attr('href'), 400);
	});

	//product counter
	jQuery('.plus, .minus').on('click', function( e ) {
		var numberField = jQuery(this).parent().find('[type="number"]');
		var currentVal = numberField.val();
		var sign = jQuery(this).val();
		if (sign === '-') {
			if (currentVal > 1) {
				numberField.val(parseFloat(currentVal) - 1);
			}
		} else {
			numberField.val(parseFloat(currentVal) + 1);
		}
	});
	
	//remove product from cart
	jQuery('a.remove').on('click', function( e ) {
		e.preventDefault();
		jQuery(this).closest('tr').remove();
	});

	//price filter
	if (jQuery().slider) {
		jQuery( ".slider-range-price" ).slider({
	      range: true,
	      min: 0,
	      max: 100000,
	      values: [ 1500, 30000 ],
	      slide: function( event, ui ) {
	        	jQuery( ".slider_price_min" ).val( ui.values[ 0 ] );
	        	jQuery( ".slider_price_max" ).val( ui.values[ 1 ] );
	      }
	    });
	    jQuery( ".slider_price_min" ).val( jQuery( ".slider-range-price" ).slider( "values", 0 ) );
	    jQuery( ".slider_price_max" ).val( jQuery( ".slider-range-price" ).slider( "values", 1 ) );
	}

	//color filter 
	jQuery(".color-filters").find("a[data-background-color]").each(function() {
		jQuery(this).css({"background-color" : jQuery(this).data("background-color")});
	});

	//adding CSS classes for elements that needs different styles depending on they widht width
	//see 'plugins.js' file
	// jQuery('#mainteasers .col-lg-4').addWidthClass({
	// 	breakpoints: [500, 600]
	// });
}); //end of "document ready" event


jQuery(window).load(function(){
	//wrap header with div for smooth sticking
	var $header = jQuery('#header');
	var headerHeight = $header.outerHeight();
	$header.wrap('<div id="header_wrapper"></div>').parent().css({height: headerHeight}); //wrap header for smooth stick and unstick
	
	//chart
	pieChart();

	
	//layerSlider
	if (jQuery().layerSlider) {
		jQuery('#layerslider').layerSlider({
			// showBarTimer: true,
			// showCircleTimer: false,
        });
	}
	
	//flexslider
	if (jQuery().flexslider) {
		jQuery("#mainslider .flexslider").flexslider({
			animation: "fade",
			useCSS: true,
			controlNav: false,   
			directionNav: true,
		    prevText: "",
		    nextText: "",
			smoothHeight: false,
			slideshowSpeed:10000,
			animationSpeed:600,
			start: function( slider ) {
				slider.find('.slide_description > div').children().css({'visibility': 'hidden'});
				slider.find('.flex-active-slide .slide_description > div').children().each(function(index){
				var self = jQuery(this);
				var animationClass = !self.data('animation') ? 'fadeInRight' : self.data('animation');
				setTimeout(function(){
						self.addClass("animated "+animationClass);
					}, index*200);
				});
			},
			after :function( slider ){
				slider.find('.flex-active-slide .slide_description > div').children().each(function(index){
				var self = jQuery(this);
				var animationClass = !self.data('animation') ? 'fadeInRight' : self.data('animation');
				setTimeout(function(){
						self.addClass("animated "+animationClass);
					}, index*200);
				});
			},
			end :function( slider ){
				slider.find('.slide_description > div').children().each(function() {
					jQuery(this).attr('class', '');
				});
			}
		});

		jQuery(".flexslider").flexslider({
			animation: "fade",
			useCSS: true,
			controlNav: true,   
			directionNav: false,
		    prevText: "",
		    nextText: "",
			smoothHeight: true,
			slideshowSpeed:5000,
			animationSpeed:800,
			after :function( slider ){
			}
		});
	}

	//preloader
	jQuery(".preloaderimg").fadeOut();
	jQuery(".preloader").delay(200).fadeOut("slow").delay(200, function(){
		jQuery(this).remove();
	});

	jQuery('body').scrollspy('refresh');


	
	//animation to elements on scroll
	if (jQuery().appear) {
		jQuery('.to_animate').appear();
		jQuery('.to_animate').filter(':appeared').each(function(index){
			var self = jQuery(this);
			var animationClass = !self.data('animation') ? 'fadeInUp' : self.data('animation');
			var animationDelay = !self.data('delay') ? 210 : self.data('delay');
			setTimeout(function(){
				self.addClass("animated " + animationClass);
			}, index * animationDelay);
		});

		jQuery('body').on('appear', '.to_animate', function(e, $affected ) {
			jQuery($affected).each(function(index){
				var self = jQuery(this);
				var animationClass = !self.data('animation') ? 'fadeInUp' : self.data('animation');
				var animationDelay = !self.data('delay') ? 210 : self.data('delay');
				setTimeout(function(){
					self.addClass("animated " + animationClass);
				}, index * animationDelay);
			});
		});
	}

	//counters init on scroll
	if (jQuery().appear) {
		jQuery('.counter').appear();
		jQuery('.counter').filter(':appeared').each(function(index){
			if (jQuery(this).hasClass('counted')) {
				return;
			} else {
				jQuery(this).countTo().addClass('counted');
			}
		});
		jQuery('body').on('appear', '.counter', function(e, $affected ) {
			jQuery($affected).each(function(index){
				if (jQuery(this).hasClass('counted')) {
					return;
				} else {
					jQuery(this).countTo().addClass('counted');
				}
				
			});
		});
	}

	//bootstrap animated progressbar
	if (jQuery().appear) {
		if (jQuery().progressbar) {
			jQuery('.progress .progress-bar').appear();
			jQuery('.progress .progress-bar').filter(':appeared').each(function(index){
				jQuery(this).progressbar({
			        transition_delay: 300
			    });
			});
			jQuery('body').on('appear', '.progress .progress-bar', function(e, $affected ) {
				jQuery($affected).each(function(index){
					jQuery(this).progressbar({
				        transition_delay: 300
				    });
				});
			});
			//animate progress bar inside bootstrap tab
			jQuery('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
				jQuery(jQuery(e.target).attr('href')).find('.progress .progress-bar').progressbar({
			        transition_delay: 300
			    });
			});
		}
	}


	//flickr
	// use http://idgettr.com/ to find your ID
	if (jQuery().jflickrfeed) {
		jQuery("#flickr").jflickrfeed({
			flickrbase: "http://api.flickr.com/services/feeds/",
			limit: 8,
			qstrings: {
				id: "74705142@N08"
			},
			itemTemplate: '<a href="{{image_b}}" data-gal="prettyPhoto[pp_gal]"><li><img alt="{{title}}" src="{{image_s}}" /></li></a>'
		}, function(data) {
			jQuery("#flickr a").prettyPhoto({
				hook: 'data-gal',
				theme: 'facebook'
	   		});
		});
	}

}); //end of "window load" event

jQuery(window).resize(function(){

	jQuery('body').scrollspy('refresh');
	jQuery("#header_wrapper").css({height: jQuery('#header').outerHeight()}); //editing header wrapper height for smooth stick and unstick

		//for header toggler on all devices
	window.toplineHeight = $("#topline").outerHeight();
	
});

jQuery(window).scroll(function() {
	//circle progress bar
	pieChart();
});
